import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_ecommerce/presentation/providers/auth_provider.dart';
import 'package:flutter_ecommerce/presentation/providers/cart_provider.dart';
import 'package:flutter_ecommerce/presentation/providers/product_provider.dart';
import 'package:flutter_ecommerce/presentation/screens/cart_screen.dart';
import 'package:flutter_ecommerce/presentation/screens/login_screen.dart';
import 'package:flutter_ecommerce/presentation/screens/search_screen.dart';
import 'package:flutter_ecommerce/presentation/widgets/category_filter.dart';
import 'package:flutter_ecommerce/presentation/widgets/product_grid.dart';
import 'package:flutter_ecommerce/presentation/widgets/sort_filter_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();
  bool _isInit = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_isInit) {
      _initData();
      _isInit = false;
    }
  }

  Future<void> _initData() async {
    final productProvider = Provider.of<ProductProvider>(context, listen: false);
    await productProvider.fetchCategories();
    await productProvider.fetchInitialProducts();
    
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 200) {
      Provider.of<ProductProvider>(context, listen: false).fetchMoreProducts();
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final cartProvider = Provider.of<CartProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter E-Commerce'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const SearchScreen()),
              );
            },
          ),
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const CartScreen()),
                  );
                },
              ),
              if (cartProvider.itemCount > 0)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    constraints: const BoxConstraints(
                      minWidth: 16,
                      minHeight: 16,
                    ),
                    child: Text(
                      '${cartProvider.itemCount}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: Icon(authProvider.isAuthenticated ? Icons.logout : Icons.login),
            onPressed: () {
              if (authProvider.isAuthenticated) {
                authProvider.logout();
              } else {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                );
              }
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Provider.of<ProductProvider>(context, listen: false).fetchInitialProducts();
        },
        child: Column(
          children: [
            const CategoryFilter(),
            const SortFilterBar(),
            Expanded(
              child: ProductGrid(scrollController: _scrollController),
            ),
          ],
        ),
      ),
    );
  }
}

