import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_ecommerce/data/models/user_model.dart';
import 'package:flutter_ecommerce/data/repositories/auth_repository_impl.dart';
import 'package:flutter_ecommerce/domain/entities/user.dart';
import 'package:flutter_ecommerce/domain/repositories/auth_repository.dart';

class AuthProvider with ChangeNotifier {
  final AuthRepository _repository = AuthRepositoryImpl(client: http.Client());
  
  User? _currentUser;
  bool _isLoading = false;
  String _error = '';

  User? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _currentUser != null;
  String get error => _error;

  Future<bool> login(String username, String password) async {
    _isLoading = true;
    _error = '';
    notifyListeners();

    try {
      _currentUser = await _repository.login(username, password);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String email, String password, String name, String phone) async {
    _isLoading = true;
    _error = '';
    notifyListeners();

    try {
      final user = UserModel(
        email: email,
        password: password,
        name: name,
        phone: phone,
      );
      
      _currentUser = await _repository.register(user);
      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}

