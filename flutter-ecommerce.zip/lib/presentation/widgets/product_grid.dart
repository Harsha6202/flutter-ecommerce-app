import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_ecommerce/presentation/providers/product_provider.dart';
import 'package:flutter_ecommerce/presentation/widgets/product_grid_item.dart';

class ProductGrid extends StatelessWidget {
  final ScrollController scrollController;

  const ProductGrid({
    Key? key,
    required this.scrollController,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);
    final products = productProvider.filteredProducts;
    final isLoading = productProvider.isLoading;
    
    if (products.isEmpty && !isLoading) {
      return const Center(
        child: Text('No products found'),
      );
    }
    
    return GridView.builder(
      controller: scrollController,
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 2 / 3,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: isLoading ? products.length + 2 : products.length,
      itemBuilder: (ctx, i) {
        if (i >= products.length) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }
        return ProductGridItem(product: products[i]);
      },
    );
  }
}

