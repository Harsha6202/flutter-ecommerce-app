import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_ecommerce/presentation/providers/product_provider.dart';

class SortFilterBar extends StatelessWidget {
  const SortFilterBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () {
                _showSortOptions(context);
              },
              icon: const Icon(Icons.sort),
              label: const Text('Sort'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () {
                _showFilterOptions(context);
              },
              icon: const Icon(Icons.filter_list),
              label: const Text('Filter'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSortOptions(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context, listen: false);
    
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            title: const Text('Featured'),
            leading: Radio<SortOption>(
              value: SortOption.featured,
              groupValue: productProvider.sortOption,
              onChanged: (SortOption? value) {
                productProvider.setSortOption(value!);
                Navigator.of(ctx).pop();
              },
            ),
          ),
          ListTile(
            title: const Text('Price: Low to High'),
            leading: Radio<SortOption>(
              value: SortOption.priceAsc,
              groupValue: productProvider.sortOption,
              onChanged: (SortOption? value) {
                productProvider.setSortOption(value!);
                Navigator.of(ctx).pop();
              },
            ),
          ),
          ListTile(
            title: const Text('Price: High to Low'),
            leading: Radio<SortOption>(
              value: SortOption.priceDesc,
              groupValue: productProvider.sortOption,
              onChanged: (SortOption? value) {
                productProvider.setSortOption(value!);
                Navigator.of(ctx).pop();
              },
            ),
          ),
          ListTile(
            title: const Text('Rating'),
            leading: Radio<SortOption>(
              value: SortOption.rating,
              groupValue: productProvider.sortOption,
              onChanged: (SortOption? value) {
                productProvider.setSortOption(value!);
                Navigator.of(ctx).pop();
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showFilterOptions(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context, listen: false);
    
    double minPrice = productProvider.minPrice;
    double maxPrice = productProvider.maxPrice;
    double minRating = productProvider.minRating;
    
    showModalBottomSheet(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setState) => Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Filter Products',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              const Text('Price Range'),
              RangeSlider(
                values: RangeValues(minPrice, maxPrice),
                min: 0,
                max: 1000,
                divisions: 100,
                labels: RangeLabels(
                  '\$${minPrice.toStringAsFixed(2)}',
                  '\$${maxPrice.toStringAsFixed(2)}',
                ),
                onChanged: (RangeValues values) {
                  setState(() {
                    minPrice = values.start;
                    maxPrice = values.end;
                  });
                },
              ),
              const SizedBox(height: 16),
              const Text('Minimum Rating'),
              Slider(
                value: minRating,
                min: 0,
                max: 5,
                divisions: 5,
                label: minRating.toString(),
                onChanged: (double value) {
                  setState(() {
                    minRating = value;
                  });
                },
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: () {
                      productProvider.resetFilters();
                      Navigator.of(ctx).pop();
                    },
                    child: const Text('Reset'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      productProvider.setPriceRange(minPrice, maxPrice);
                      productProvider.setMinRating(minRating);
                      Navigator.of(ctx).pop();
                    },
                    child: const Text('Apply'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

