import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_ecommerce/data/repositories/product_repository_impl.dart';
import 'package:flutter_ecommerce/domain/entities/product.dart';
import 'package:flutter_ecommerce/domain/repositories/product_repository.dart';

enum SortOption { featured, priceAsc, priceDesc, rating }

class ProductProvider with ChangeNotifier {
  final ProductRepository _repository = ProductRepositoryImpl(client: http.Client());
  
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  List<String> _categories = [];
  bool _isLoading = false;
  bool _hasMore = true;
  int _currentPage = 0;
  int _limit = 10;
  String _selectedCategory = '';
  SortOption _sortOption = SortOption.featured;
  double _minPrice = 0;
  double _maxPrice = 1000;
  double _minRating = 0;

  List<Product> get products => _products;
  List<Product> get filteredProducts => _filteredProducts;
  List<String> get categories => _categories;
  bool get isLoading => _isLoading;
  bool get hasMore => _hasMore;
  String get selectedCategory => _selectedCategory;
  SortOption get sortOption => _sortOption;
  double get minPrice => _minPrice;
  double get maxPrice => _maxPrice;
  double get minRating => _minRating;

  Future<void> fetchInitialProducts() async {
    _isLoading = true;
    _currentPage = 0;
    _hasMore = true;
    notifyListeners();

    try {
      _products = await _repository.getProducts(limit: _limit, offset: 0);
      _applyFiltersAndSort();
    } catch (e) {
      debugPrint('Error fetching products: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchMoreProducts() async {
    if (_isLoading || !_hasMore) return;

    _isLoading = true;
    notifyListeners();

    try {
      _currentPage++;
      final newProducts = await _repository.getProducts(
        limit: _limit,
        offset: _currentPage * _limit,
      );

      if (newProducts.isEmpty) {
        _hasMore = false;
      } else {
        _products.addAll(newProducts);
        _applyFiltersAndSort();
      }
    } catch (e) {
      debugPrint('Error fetching more products: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchCategories() async {
    try {
      _categories = await _repository.getCategories();
      notifyListeners();
    } catch (e) {
      debugPrint('Error fetching categories: $e');
    }
  }

  Future<Product> fetchProductById(int id) async {
    try {
      return await _repository.getProductById(id);
    } catch (e) {
      debugPrint('Error fetching product details: $e');
      rethrow;
    }
  }

  Future<void> fetchProductsByCategory(String category) async {
    _isLoading = true;
    notifyListeners();

    try {
      if (category.isEmpty) {
        await fetchInitialProducts();
      } else {
        _products = await _repository.getProductsByCategory(category);
        _applyFiltersAndSort();
      }
    } catch (e) {
      debugPrint('Error fetching products by category: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> searchProducts(String query) async {
    _isLoading = true;
    notifyListeners();

    try {
      if (query.isEmpty) {
        await fetchInitialProducts();
      } else {
        _products = await _repository.searchProducts(query);
        _applyFiltersAndSort();
      }
    } catch (e) {
      debugPrint('Error searching products: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void setCategory(String category) {
    _selectedCategory = category;
    fetchProductsByCategory(category);
  }

  void setSortOption(SortOption option) {
    _sortOption = option;
    _applyFiltersAndSort();
    notifyListeners();
  }

  void setPriceRange(double min, double max) {
    _minPrice = min;
    _maxPrice = max;
    _applyFiltersAndSort();
    notifyListeners();
  }

  void setMinRating(double rating) {
    _minRating = rating;
    _applyFiltersAndSort();
    notifyListeners();
  }

  void _applyFiltersAndSort() {
    // Apply filters
    _filteredProducts = _products.where((product) {
      // Price filter
      if (product.price < _minPrice || product.price > _maxPrice) {
        return false;
      }
      
      // Rating filter
      if (product.rating.rate < _minRating) {
        return false;
      }
      
      // Category filter
      if (_selectedCategory.isNotEmpty && product.category != _selectedCategory) {
        return false;
      }
      
      return true;
    }).toList();

    // Apply sorting
    _filteredProducts.sort((a, b) {
      switch (_sortOption) {
        case SortOption.priceAsc:
          return a.price.compareTo(b.price);
        case SortOption.priceDesc:
          return b.price.compareTo(a.price);
        case SortOption.rating:
          return b.rating.rate.compareTo(a.rating.rate);
        case SortOption.featured:
        default:
          // For featured, we'll use a combination of rating and review count
          final aScore = a.rating.rate * (a.rating.count / 100);
          final bScore = b.rating.rate * (b.rating.count / 100);
          return bScore.compareTo(aScore);
      }
    });
  }

  void resetFilters() {
    _selectedCategory = '';
    _sortOption = SortOption.featured;
    _minPrice = 0;
    _maxPrice = 1000;
    _minRating = 0;
    _applyFiltersAndSort();
    notifyListeners();
  }
}

