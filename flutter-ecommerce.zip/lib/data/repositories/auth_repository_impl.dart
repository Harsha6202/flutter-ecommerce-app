import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_ecommerce/core/constants/api_constants.dart';
import 'package:flutter_ecommerce/data/models/user_model.dart';
import 'package:flutter_ecommerce/domain/entities/user.dart';
import 'package:flutter_ecommerce/domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  final http.Client client;

  AuthRepositoryImpl({required this.client});

  @override
  Future<User> login(String username, String password) async {
    try {
      final response = await client.post(
        Uri.parse('${ApiConstants.baseUrl}${ApiConstants.login}'),
        body: {
          'username': username,
          'password': password,
        },
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        return UserModel(
          email: username,
          password: password,
          token: data['token'],
        );
      } else {
        throw Exception('Failed to login');
      }
    } catch (e) {
      throw Exception('Failed to login: $e');
    }
  }

  @override
  Future<User> register(User user) async {
    try {
      // Note: The fake API doesn't actually create a new user, this is just for demonstration
      final response = await client.post(
        Uri.parse('${ApiConstants.baseUrl}${ApiConstants.users}'),
        body: (user as UserModel).toJson(),
      );

      if (response.statusCode == 200) {
        return UserModel.fromJson(json.decode(response.body));
      } else {
        throw Exception('Failed to register');
      }
    } catch (e) {
      throw Exception('Failed to register: $e');
    }
  }
}

