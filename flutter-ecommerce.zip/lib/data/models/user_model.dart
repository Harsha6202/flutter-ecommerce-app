import 'package:flutter_ecommerce/domain/entities/user.dart';

class UserModel extends User {
  UserModel({
    int? id,
    required String email,
    required String password,
    String? name,
    String? phone,
    String? token,
  }) : super(
          id: id,
          email: email,
          password: password,
          name: name,
          phone: phone,
          token: token,
        );

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      email: json['email'],
      password: json['password'],
      name: json['name'] != null ? json['name']['firstname'] + ' ' + json['name']['lastname'] : null,
      phone: json['phone'],
      token: json['token'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'email': email,
      'password': password,
      if (name != null) 'name': name,
      if (phone != null) 'phone': phone,
    };
  }
}

