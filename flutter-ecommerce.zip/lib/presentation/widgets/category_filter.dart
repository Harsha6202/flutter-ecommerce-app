import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_ecommerce/presentation/providers/product_provider.dart';

class CategoryFilter extends StatelessWidget {
  const CategoryFilter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);
    final categories = productProvider.categories;
    final selectedCategory = productProvider.selectedCategory;
    
    return Container(
      height: 50,
      margin: const EdgeInsets.only(top: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: categories.length + 1, // +1 for "All" category
        itemBuilder: (ctx, i) {
          final isAll = i == 0;
          final category = isAll ? '' : categories[i - 1];
          final isSelected = isAll ? selectedCategory.isEmpty : selectedCategory == category;
          
          return Container(
            margin: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(isAll ? 'All' : _formatCategoryName(category)),
              selected: isSelected,
              onSelected: (selected) {
                if (selected) {
                  productProvider.setCategory(category);
                }
              },
            ),
          );
        },
      ),
    );
  }

  String _formatCategoryName(String name) {
    return name.split(' ').map((word) => word.length > 0 
        ? '${word[0].toUpperCase()}${word.substring(1)}' 
        : '').join(' ');
  }
}

