import 'package:flutter_ecommerce/domain/entities/user.dart';

abstract class AuthRepository {
  Future<User> login(String username, String password);
  Future<User> register(User user);
}

