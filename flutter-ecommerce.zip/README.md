# Flutter E-Commerce Application

A comprehensive e-commerce mobile application built with Flutter that demonstrates modern app development practices and clean architecture.

## Features

- **Homepage**: Displays featured products with infinite scrolling
- **Product Detail Page**: Shows detailed product information and reviews
- **Search Functionality**: Search products by name or description
- **User Authentication**: Login and registration with validation
- **Product Sorting & Filtering**: Sort by price, popularity, rating, and filter by categories, price ranges, and ratings
- **Cart Functionality**: Add/remove products, adjust quantities, and checkout

## Screenshots

[Add screenshots of your application here]

## Getting Started

### Prerequisites

- Flutter SDK (3.0.0 or higher)
- Dart SDK (3.0.0 or higher)
- Android Studio / VS Code
- Android Emulator / iOS Simulator / Physical Device

### Installation

1. Clone the repository:

