import 'package:flutter_ecommerce/domain/entities/product.dart';

abstract class ProductRepository {
  Future<List<Product>> getProducts({int limit = 10, int offset = 0});
  Future<Product> getProductById(int id);
  Future<List<String>> getCategories();
  Future<List<Product>> getProductsByCategory(String category);
  Future<List<Product>> searchProducts(String query);
}

