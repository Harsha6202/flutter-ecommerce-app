import 'package:flutter/material.dart';
import 'package:flutter_ecommerce/presentation/screens/splash_screen.dart';
import 'package:flutter_ecommerce/core/constants/app_theme.dart';

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter E-Commerce',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const SplashScreen(),
    );
  }
}

